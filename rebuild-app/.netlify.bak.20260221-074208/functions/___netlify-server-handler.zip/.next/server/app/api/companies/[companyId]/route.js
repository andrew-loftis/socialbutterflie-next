var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/companies/[companyId]/route.js")
R.c("server/chunks/[root-of-the-server]__910a96e3._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_api_companies_[companyId]_route_actions_428308ca.js")
R.m(39744)
module.exports=R.m(39744).exports
