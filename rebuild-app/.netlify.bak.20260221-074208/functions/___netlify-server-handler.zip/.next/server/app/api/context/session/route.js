var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/context/session/route.js")
R.c("server/chunks/[root-of-the-server]__6d47c6a4._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/_next-internal_server_app_api_context_session_route_actions_176c9025.js")
R.m(97372)
module.exports=R.m(97372).exports
