var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/studio/jobs/route.js")
R.c("server/chunks/[root-of-the-server]__5d8b9356._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/_next-internal_server_app_api_studio_jobs_route_actions_b3cb3162.js")
R.m(23003)
module.exports=R.m(23003).exports
