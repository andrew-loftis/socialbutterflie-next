var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/studio/jobs/[jobId]/route.js")
R.c("server/chunks/[root-of-the-server]__9b6d426b._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_api_studio_jobs_[jobId]_route_actions_f03db67c.js")
R.m(59376)
module.exports=R.m(59376).exports
