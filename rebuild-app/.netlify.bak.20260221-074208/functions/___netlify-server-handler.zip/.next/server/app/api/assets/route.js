var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assets/route.js")
R.c("server/chunks/[root-of-the-server]__6081f775._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_api_assets_route_actions_d4eff541.js")
R.m(81169)
module.exports=R.m(81169).exports
