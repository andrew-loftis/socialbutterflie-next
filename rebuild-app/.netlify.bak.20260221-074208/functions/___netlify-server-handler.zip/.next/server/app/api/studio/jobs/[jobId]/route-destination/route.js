var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/studio/jobs/[jobId]/route-destination/route.js")
R.c("server/chunks/[root-of-the-server]__746f2af4._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/ce889_server_app_api_studio_jobs_[jobId]_route-destination_route_actions_a53d0c71.js")
R.m(18352)
module.exports=R.m(18352).exports
