var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/usage/ai/consume/route.js")
R.c("server/chunks/[root-of-the-server]__f417f3ae._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/_next-internal_server_app_api_usage_ai_consume_route_actions_46b2434e.js")
R.m(33123)
module.exports=R.m(33123).exports
