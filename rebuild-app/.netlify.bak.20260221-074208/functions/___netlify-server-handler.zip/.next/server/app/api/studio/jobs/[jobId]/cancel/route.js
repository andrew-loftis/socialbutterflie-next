var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/studio/jobs/[jobId]/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__dc986739._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_api_studio_jobs_[jobId]_cancel_route_actions_70eed43f.js")
R.m(15420)
module.exports=R.m(15420).exports
