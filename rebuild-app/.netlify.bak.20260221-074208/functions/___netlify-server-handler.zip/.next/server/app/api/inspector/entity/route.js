var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inspector/entity/route.js")
R.c("server/chunks/[root-of-the-server]__dd3ea50b._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_api_inspector_entity_route_actions_7261664c.js")
R.m(94585)
module.exports=R.m(94585).exports
