var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/companies/[companyId]/versions/route.js")
R.c("server/chunks/[root-of-the-server]__3a9e3e07._.js")
R.c("server/chunks/_96458ebb._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/ce889_server_app_api_companies_[companyId]_versions_route_actions_9a47c526.js")
R.m(53071)
module.exports=R.m(53071).exports
