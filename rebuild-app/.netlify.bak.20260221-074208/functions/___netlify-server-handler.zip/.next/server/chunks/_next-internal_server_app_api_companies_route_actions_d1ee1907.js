module.exports=[69168,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_companies_route_actions_d1ee1907.js.map