module.exports=[40579,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_companies_%5BcompanyId%5D_versions_route_actions_9a47c526.js.map