module.exports=[75613,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_companies_page_actions_96af1dc8.js.map