module.exports=[21381,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_build_page_actions_adfab29d.js.map