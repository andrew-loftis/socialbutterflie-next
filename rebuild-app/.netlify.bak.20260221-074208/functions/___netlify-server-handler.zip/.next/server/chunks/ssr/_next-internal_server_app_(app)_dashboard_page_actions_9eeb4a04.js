module.exports=[20510,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_dashboard_page_actions_9eeb4a04.js.map