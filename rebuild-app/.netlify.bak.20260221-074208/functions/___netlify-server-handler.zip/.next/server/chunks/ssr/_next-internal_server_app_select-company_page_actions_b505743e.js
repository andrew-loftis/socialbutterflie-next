module.exports=[82630,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_select-company_page_actions_b505743e.js.map