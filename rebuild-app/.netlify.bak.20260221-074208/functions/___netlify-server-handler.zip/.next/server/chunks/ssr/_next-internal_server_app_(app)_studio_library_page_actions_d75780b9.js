module.exports=[81055,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_studio_library_page_actions_d75780b9.js.map