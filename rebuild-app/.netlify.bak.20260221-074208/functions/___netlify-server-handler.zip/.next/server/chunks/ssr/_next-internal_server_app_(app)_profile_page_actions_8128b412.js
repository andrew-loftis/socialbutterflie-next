module.exports=[43978,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_profile_page_actions_8128b412.js.map