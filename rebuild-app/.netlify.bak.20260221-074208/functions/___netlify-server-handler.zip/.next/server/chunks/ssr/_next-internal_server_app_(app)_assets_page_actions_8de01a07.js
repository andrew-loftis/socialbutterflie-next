module.exports=[52745,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_assets_page_actions_8de01a07.js.map