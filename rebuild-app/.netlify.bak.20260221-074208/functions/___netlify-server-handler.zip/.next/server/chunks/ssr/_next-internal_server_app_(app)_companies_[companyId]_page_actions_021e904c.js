module.exports=[31198,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_companies_%5BcompanyId%5D_page_actions_021e904c.js.map