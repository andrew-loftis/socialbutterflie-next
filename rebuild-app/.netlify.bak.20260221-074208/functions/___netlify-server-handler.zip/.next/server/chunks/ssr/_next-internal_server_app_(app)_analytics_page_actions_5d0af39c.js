module.exports=[18566,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_analytics_page_actions_5d0af39c.js.map