module.exports=[87153,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_studio_page_actions_d7193365.js.map