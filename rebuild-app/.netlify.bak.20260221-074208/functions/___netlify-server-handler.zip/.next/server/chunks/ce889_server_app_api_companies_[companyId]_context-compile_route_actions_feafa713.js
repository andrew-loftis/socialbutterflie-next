module.exports=[15704,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_companies_%5BcompanyId%5D_context-compile_route_actions_feafa713.js.map