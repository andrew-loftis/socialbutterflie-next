module.exports=[87872,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inspector_entity_route_actions_7261664c.js.map