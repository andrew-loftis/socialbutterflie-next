module.exports=[50328,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_companies_%5BcompanyId%5D_route_actions_428308ca.js.map